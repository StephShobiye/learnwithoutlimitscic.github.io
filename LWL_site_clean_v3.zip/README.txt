Upload the ZIP contents to the repository root. Keep your CNAME. Put your app ZIP in /downloads/ named aln-parent-guide-app-latest.zip .
