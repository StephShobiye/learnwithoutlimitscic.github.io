Placeholder for chatbot logic
